# XQUIC

## 简介

阿里巴巴发布的XQUIC库

* **是一个遵循IETF标准的QUIC和HTTP/3的客户端和服务端实现。** 目前支持的QUIC版本是v1和draft-29。

* **是跨平台的。** 目前支持Android、iOS、Linux、macOS和Windows。绝大部分代码被用于我们自己的产品，并已在安卓、iOS APP以及服务端上进行了大规模测试。

* **目前仍在积极开发中。** 我们定期与其他QUIC实现进行[互通性测试](https://interop.seemann.io/)。

## 依赖

编译XQUIC，你需要：
* CMake
* BoringSSL 或者 BabaSSL

运行测试用例，你需要：
* libevent
* CUnit

## 快速入门指南

XQUIC 支持 BoringSSL 和 BabaSSL。

### 使用 BabaSSL（Tongsuo） 编译

```bash
# 获取 XQUIC 源码
git clone https://github.com/alibaba/xquic.git
cd xquic

# 编译 BabaSSL(Tongsuo)
git clone -b 8.3-stable https://github.com/Tongsuo-Project/Tongsuo.git ./third_party/babassl
cd ./third_party/babassl/
./config --prefix=/usr/local/babassl
make -j
SSL_TYPE_STR="babassl"
SSL_PATH_STR="${PWD}"
cd -

# 使用 BabaSSL（Tongsuo） 编译 XQUIC
# 选择BabaSSL编译XQUIC时，会默认从/usr/local/babassl寻找头文件、依赖库，如果BabaSSL在其
# 他位置，可以通过SSL_PATH指定位置。
# 在编译测试程序时，依赖了libevent、CUnit，默认会从系统安装路径下寻找，如果用户部署在特定位置
# 下，可以通过-DCUNIT_DIR、-DLIBEVENT_DIR指定目录。
git submodule update --init --recursive
mkdir -p build; cd build
cmake -DGCOV=on -DCMAKE_BUILD_TYPE=Debug -DXQC_ENABLE_TESTING=1 -DXQC_SUPPORT_SENDMMSG_BUILD=1 -DXQC_ENABLE_EVENT_LOG=1 -DXQC_ENABLE_BBR2=1 -DXQC_ENABLE_RENO=1 -DSSL_TYPE=${SSL_TYPE_STR} -DSSL_PATH=${SSL_PATH_STR} ..

# 如果CMake发生错误，则结束编译
if [ $? -ne 0 ]; then
    echo "cmake failed"
    exit 1
fi

make -j
```

### 使用 BoringSSL 编译

```bash
# 获取 XQUIC 源码
git clone https://github.com/alibaba/xquic.git
cd xquic

# 编译 BoringSSL
git clone https://github.com/google/boringssl.git ./third_party/boringssl
cd ./third_party/boringssl
mkdir -p build && cd build
cmake -DBUILD_SHARED_LIBS=0 -DCMAKE_C_FLAGS="-fPIC" -DCMAKE_CXX_FLAGS="-fPIC" ..
make ssl crypto
cd ..
SSL_TYPE_STR="boringssl"
SSL_PATH_STR="${PWD}"
cd ../..

# 使用 BoringSSL 编译 XQUIC
# 选择boringssl编译XQUIC时，会默认从源码third_party/boringssl寻找头文件、依赖库，如果
# boringssl在其他位置，可以通过SSL_PATH指定位置。
# 在编译测试程序时，依赖了libevent、CUnit，默认会从系统安装路径下寻找，如果用户部署在特定位置
# 下，可以通过-DCUNIT_DIR、-DLIBEVENT_DIR指定目录。
git submodule update --init --recursive
mkdir -p build; cd build
cmake -DGCOV=on -DCMAKE_BUILD_TYPE=Debug -DXQC_ENABLE_TESTING=1 -DXQC_SUPPORT_SENDMMSG_BUILD=1 -DXQC_ENABLE_EVENT_LOG=1 -DXQC_ENABLE_BBR2=1 -DXQC_ENABLE_RENO=1 -DSSL_TYPE=${SSL_TYPE_STR} -DSSL_PATH=${SSL_PATH_STR} ..

# 如果CMake发生错误，则结束编译
if [ $? -ne 0 ]; then
    echo "cmake failed"
    exit 1
fi

make -j
```

### 运行测试用例

```bash
sh ../scripts/xquic_test.sh
```

## 文档

* 关于API的使用，详见 [API文档](../../docs/API.md)。
* 关于平台支持的细节，详见 [平台文档](../../docs/Platforms.md)。
* 关于 IETF QUIC Protocol 的中文翻译，详见翻译文档。
    - [RFC8999-invariants-zh](../../docs/translation/rfc8999-invariants-zh.md)
    - [RFC9000-transport-zh](../../docs/translation/rfc9000-transport-zh.md)
    - [RFC9001-tls-zh](../../docs/translation/rfc9001-tls-zh.md)
    - [RFC9002-recovery-zh](../../docs/translation/rfc9002-recovery-zh.md)
    - [draft-ietf-quic-http-34-zh](../../docs/translation/draft-ietf-quic-http-34-zh.md)
    - [draft-ietf-quic-qpack-21-zh](../../docs/translation/draft-ietf-quic-qpack-21-zh.md)
    - [RFC9221-datagram-zh](../../docs/translation/rfc9221-datagram-zh.md)
* 关于event_log模块的使用, 详见 [Event_log module docs](../../docs/docs-zh/Event_log-zh.md)。
* 关于测试，参见 [测试文档](../../docs/docs-zh/Testing-zh.md)。
* 关于常见问题，参见 [FAQs](../../docs/docs-zh/FAQ-zh.md) 和 [Trouble Shooting Guide](../../docs/docs-zh/Troubleshooting-zh.md)。

## Contributing

我们希望你能为XQUIC做出贡献，帮助它变得比现在更好！我们鼓励并重视所有类型的贡献，请参阅我们的[贡献指南](./CONTRIBUTING-zh.md)了解更多信息。

如果你有任何问题，请随时在我们的[讨论区](https://github.com/alibaba/xquic/discussions)开启一个新的讨论主题。

## License

XQUIC 使用 Apache 2.0 许可证。
